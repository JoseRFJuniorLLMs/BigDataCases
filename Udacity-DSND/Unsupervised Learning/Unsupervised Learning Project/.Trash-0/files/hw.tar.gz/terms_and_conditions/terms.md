In addition to Udacity's Terms of Use and other policies, your
downloading and use of the **AZ Direct GmbH** data solely for use in the
**Unsupervised Learning** and **Bertelsmann Capstone** projects are
governed by the following additional terms and conditions. You agree
to **AZ Direct GmbH's** General Terms provided below and that you only
have the right to download and use the **AZ Direct GmbH** data solely to
complete the data mining task which is part of the **Unsupervised
Learning** and **Bertelsmann Capstone** projects for the Udacity Data
Science Nanodegree program. You are prohibited from using the **AZ
Direct GmbH** data in any other context. You are also required and
hereby represent and warrant that you will delete any and all data you
downloaded within 2 weeks after your completion of the **Unsupervised
Learning** and **Bertelsmann Capstone** projects and the program. If you
do not agree to these additional terms, you will not be allowed to
access the data for this project.

<div class="terms-and-conditions-pdf">
<object data="/tree/terms_and_conditions/terms.pdf" type="application/pdf" width="100%">
    <p>It appears you do not have a PDF plugin for this browser. 
        You can <a href="/tree/terms_and_conditions/terms.pdf">click here to download the PDF file.</a>
    </p>
</object>
</div>

